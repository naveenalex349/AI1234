
# Noscreensaver

* While writing from a pdf on our computer after sometime we need to move the mouse in order to prevent the screensaver from being turned on.
* Or sometimes when the user needs to keep the computer always engaged. 
---
#### We can use this then. 


## Run Locally

Just copy the code and ensure you have pyautogui installed.

If not then you can install by

` pip install pyautogui `

To close the program if run from terminal press `Ctrl+C` or if from IDLE then just simply close the interface.