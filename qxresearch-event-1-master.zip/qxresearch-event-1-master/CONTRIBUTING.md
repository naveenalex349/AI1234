### What is qxresearch?

**QX Research** is an online Developer **|** Research club in collaboration with `Mozilla Campus Club`. We focus on the application of `Programming` with `AI` `ML` `Cloud Computing` `Computer Vision` `IOT` etc. Our Research Sessions will take place remotely over [video chat](https://www.youtube.com/channel/UCX7oe66V8zyFpAJyMfPL9VA), so you can be anywhere in the world.

### Contributing

Any kind of contributions to `qxresearch-event-1` are welcome. Contributions are what make the open source community such an amazing place to learn, inspire, and create.

1. [**Fork**](https://github.com/qxresearch/qxresearch-event-1/fork) the Project
2. Create your Feature Branch
3. Commit your Changes
4. Push to the Branch
5. Open a [**Pull Request**](https://github.com/qxresearch/qxresearch-event-1/pulls)
