---
name: Bug report
about: Create a report to help us improve
title: ''
labels: Birthday-Reminder, Extract-mp3-from-mp4, Link-Shortener, Password-Protect-PDF,
  Random-Password-Generator, Terminal-Tricks, Voice-Recorder, Voice-Visualization-Tool,
  Windows-Notification, bug, documentation, good first issue, help wanted, question
assignees: xiaowuc2

---

**Describe the bug**
If the program does produce any runtime error or lack some special feature then create an issue!


**Expected behavior**
Run and produce the output as it should be(described in readme.md)

**Screenshots**


**Desktop (please complete the following information):**
 - OS: Windows
 - Browser: chrome, safari, brave, edge

**Additional context**
Python must be installed in the machine.

**ThankYou**
